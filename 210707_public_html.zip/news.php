<?php
$ch=curl.init();

?>