function sum(first, second) {
    console.log('a');
    return first + second;
    console.log('b');
}

console.log(sum(2, 4));
